Configuration for the cluster; a basic GKE cluster with workload
identity.
